
%%% Basel Credit risk model

%%
clc
close
clear 

%   1. Roncalli Figure 3.21

N=100;
EAD = 1;
E_LGD = 0.5;
p_i = 0.05;
alpha=linspace(0,0.99,100);
rho=[0.1;0.3];
l = linspace(0,10,1000);
F_inverse= N * EAD* E_LGD* normcdf((norminv(p_i)+sqrt(rho).*norminv(alpha))./(sqrt(1-rho)));
F_l = normcdf((sqrt(1-rho).*(norminv((l)/(N*EAD*E_LGD)))-norminv(p_i))./(sqrt(rho)));
f_l = 1./(N*EAD*E_LGD*sqrt((rho)./(1-rho)).*(1)./(normpdf(norminv(F_l))).*normpdf((norminv(p_i)+sqrt(rho).*norminv(F_l))./(sqrt(1-rho))));

%plot

%figure;
bluecolor=[0, 0, 125/255];
redcolor=[126/255, 0, 0];
tiledlayout(2,2);
nexttile
plot(alpha,F_inverse(1,:),"Color",bluecolor);
hold on
plot(alpha,F_inverse(2,:),"Color",redcolor,"LineStyle","--");
xlabel("\alpha")
title("Quantile function")
legend("\rho = 10%","\rho = 30%")

nexttile
plot(l,F_l(1,:),"Color",bluecolor);
hold on
plot(l,F_l(2,:),"Color",redcolor,"LineStyle","--");
xlabel("Loss")
title("Cumulative distribution function")

nexttile
plot(l,f_l(1,:),"Color",bluecolor);
hold on
plot(l,f_l(2,:),"Color",redcolor,"LineStyle","--");
xlabel("Loss")
title("Probability density function")
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/Figure3_21.png', '-png', '-transparent');

%%
clc
rho=0.1;
alpha=[0.10 0.25 0.50 0.75 0.90 0.95]
l=[0.1 1 2 3 4 5]
F_inverse= N * EAD* E_LGD* normcdf((norminv(p_i)+sqrt(rho).*norminv(alpha))./(sqrt(1-rho)));
F_l = normcdf((sqrt(1-rho).*(norminv((l)/(N*EAD*E_LGD)))-norminv(p_i))./(sqrt(rho)));
f_l = 1./(N*EAD*E_LGD*sqrt((rho)./(1-rho)).*(1)./(normpdf(norminv(F_l))).*normpdf((norminv(p_i)+sqrt(rho).*norminv(F_l))./(sqrt(1-rho))));

disp(table(round(l,2),'VariableNames',"l"))
disp(table(round(F_l*100,2),'VariableNames',"F(l)"))
disp(table(round(f_l*100,2),'VariableNames',"f(l)"))
disp(table(round(alpha,2),'VariableNames',"alpha"))
disp(table(round(F_inverse,2),'VariableNames',"F inverse"))




%%

%2. 
clc
close
clear

bluecolor=[0, 0, 125/255];
redcolor=[126/255, 0, 0];
greencolor=[0, 126/255,0];
w=100;
rho=0.2;
alpha=0.9;
p_i = linspace(0,1,100);

%figure;
tiledlayout(2,2);

nexttile
E_LGD = [0.7;0.3];
RC = w*E_LGD*normcdf((norminv(p_i)+sqrt(rho).*norminv(alpha))/(sqrt(1-rho)));
plot(p_i*100,RC(1,:),"Color",bluecolor);
hold on
plot(p_i*100,RC(2,:),"Color",redcolor,"LineStyle","--");
legend("E[LGD]=70%","E[LGD]=30%","Location","best")
title("\alpha = 90%")
xlabel("p_i (in %)")

nexttile
E_LGD=0.7;
alpha = [0.9;0.995;0.40];
RC = w*E_LGD*normcdf((norminv(p_i)+sqrt(rho).*norminv(alpha))/(sqrt(1-rho)));
plot(p_i*100,RC(1,:),"Color",bluecolor);
hold on
plot(p_i*100,RC(2,:),"Color",redcolor,"LineStyle","--");
hold on
plot(p_i*100,RC(3,:),"Color",greencolor,"LineStyle","-.");
legend("\alpha=90%","\alpha=99.5%","\alpha=40%","Location","best")
title("\rho = 20%")
xlabel("p_i (in %)")

nexttile
rho = linspace(0,1,100);
alpha=0.9;
p_i = [0.05;0.10];
RC = w*E_LGD*normcdf((norminv(p_i)+sqrt(rho).*norminv(alpha))./(sqrt(1-rho)));
plot(rho*100,RC(1,:),"Color",bluecolor);
hold on
plot(rho*100,RC(2,:),"Color",redcolor,"LineStyle","--");
legend("p_i =5%","p_i =10%","Location","best");
title("\alpha = 90%")
xlabel("\rho (in %)")

nexttile
alpha=0.999;
RC = w*E_LGD*normcdf((norminv(p_i)+sqrt(rho).*norminv(alpha))./(sqrt(1-rho)));
plot(rho*100,RC(1,:),"Color",bluecolor);
hold on
plot(rho*100,RC(2,:),"Color",redcolor,"LineStyle","--");
legend("p_i =5%","p_i =10%","Location","best");
title("\alpha = 99.9%")
xlabel("\rho (in %)")
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/Figure3_22.png', '-png', '-transparent');
%%
%%% Loss Given Default Estimation
%%

%   2.1

clc
close
clear 

bluecolor=[0, 0, 125/255];
redcolor=[126/255, 0, 0];
greencolor=[0, 126/255,0];

LGD = [0.68 0.90 0.22 0.45 0.17 0.25 0.89 0.65 0.75 0.56 0.87 0.92 0.46];
LGD = sort(LGD);

% Method of moments
u=mean(LGD);
sigma = std(LGD);
alpha_mm = (u^2*(1-u))/(sigma)^2 - u;
beta_mm = (u*(1-u)^2)/(sigma)^2 - (1-u);


% Maximum Likelihood Estimation
MLE = mle(LGD,"distribution","Beta");
alpha_mle = MLE(1);
beta_mle = MLE(2);


fprintf('Beta MM value is %0f , Alpha MM value is %0f\n', beta_mm,alpha_mm);
fprintf('Beta MLE value is %0f , Alpha MLE value is %0f\n', beta_mle,alpha_mle);


%   plot
line = linspace(0,0.9975,100);
%figure;
PDF_mm = betapdf(line,alpha_mm,beta_mm);
PDF_mle = betapdf(line,alpha_mle,beta_mle);
plot(line,PDF_mm,"Color",bluecolor)
hold on
plot(line,PDF_mle,"Color",redcolor,"LineStyle","--");
ax = gca;
ax.XTick = 0:0.2:1;
ax.YTick = 0:0.5:2;
xlabel("LGD");
legend(ax,"MM","MLE","Location","best");
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/Figure2_1.png', '-png', '-transparent');
%%

%   2.2.1 

clc
close
clear
bluecolor=[0, 0, 125/255];
redcolor=[126/255, 0, 0];
greencolor=[0, 126/255,0];

LGD=[0 0.10 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.90 1];
p=[0.01 0.02 0.10 0.25 0.10 0.02 0 0.02 0.10 0.25 0.10 0.02 0.01]; %They sum up to 1
final_LGD=repelem(LGD,p*100);

u=mean(final_LGD);
sigma = std(final_LGD);
alpha_mm = (u^2*(1-u))/(sigma)^2 - u;
beta_mm = (u*(1-u)^2)/(sigma)^2 - (1-u);
line = linspace(0,1,100);
PDF_mm = betapdf(line,alpha_mm,beta_mm)*(1/2)*sigma;

%figure;
plot(line,PDF_mm,"Color",redcolor)
hold on
bar(LGD,p,"FaceColor",bluecolor)
legend("Calibrated Beta","Location","north")
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/Figure2_2_1.png', '-png', '-transparent');

%%

% 2.2.2 point
Q=10;
N=10000;
EAD=1000;
T=5;
LGD=[0 0.10 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.90 1];
p=[0.01 0.02 0.10 0.25 0.10 0.02 0 0.02 0.10 0.25 0.10 0.02 0.01]; %They sum up to 1
lambda=[0.0010 0.0010 0.0025 0.0025 0.0050 0.01 0.0250 0.05 0.05 0.10];
%L=0;
tau=exp(lambda);
indicator=(tau<=T);
N=100;
for j=1:N
L=0;
for i=1:Q
    L=L+EAD*final_LGD*indicator(i);
end
end

N=100;
Q=10;
L=0;
Final_L=zeros(1,N);
a=exp(1/lambda(10));


%%

N=10000;
Beta=sum(EAD*betarnd(repmat(alpha_mm,N,Q),repmat(beta_mm,N,Q)).*(exprnd(1./repmat(lambda,N,1))<=T),2);
Granular=sum(EAD*0.5*(exprnd(1./repmat(lambda,N,1))<=T),2);
final_LGD2=repelem(LGD,p*N*Q);
Empirical=sum(EAD.*reshape(final_LGD2(randperm(numel(final_LGD2))),N,Q).*(exprnd(1./repmat(lambda,N,1))<=T),2);
Var_99_empirical=prctile(Empirical,99)
Var_995_empirical=prctile(Empirical,99.5)
Var_999_empirical=prctile(Empirical,99.9)
Var_99_granular=prctile(Empirical,99)
Var_995_granular=prctile(Empirical,99.5)
Var_999_granular=prctile(Empirical,99.9)
Var_99_beta=prctile(Empirical,99)
Var_995_beta=prctile(Empirical,99.5)
Var_999_beta=prctile(Empirical,99.9)
fprintf("VaR Empirical 99 level is %0f\n",Var_99_empirical)
fprintf("VaR Empirical 99.5 level is %0f\n",Var_995_empirical)
fprintf("VaR Empirical 99.9 level is %0f\n",Var_999_empirical)
fprintf("VaR Granular 99 level is %0f\n",Var_99_granular)
fprintf("VaR Granular 99.5 level is %0f\n",Var_995_granular)
fprintf("VaR Granular 99.9 level is %0f\n",Var_999_granular)
fprintf("VaR Beta 99 level is %0f\n",Var_99_beta)
fprintf("VaR Beta 99.5 level is %0f\n",Var_995_beta)
fprintf("VaR Beta 99.9 level is %0f\n",Var_999_beta)

%figure;
tiledlayout(2,2);

nexttile
histogram(Beta,"Normalization","percentage","FaceColor",redcolor)
title("Beta distribution")
xlabel("Loss")
nexttile
histogram(Granular,"Normalization","percentage","FaceColor",bluecolor)
title("LGD=50%")
xlabel("Loss")

nexttile
histogram(Empirical,unique(Empirical),"Normalization","percentage","FaceColor",greencolor)
title("Empirical distribution")
xlabel("Loss")
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/Figure2_3.png', '-png', '-transparent');

%%

%   1.
clc
close
clear

r=0.02;
S_0=8086;
T=1;
F=35000;
vol_eq=0.18;
[PD,DD,V_0,vol_v]=mertonmodel(S_0,vol_eq,F,r);

%   either you subtract S_0 from V_0, or we can use the its formula from BS
D_0=V_0 - S_0;

%   for the sake of completeness, i compute it also with the BS formula
d1=(log(V_0 / F)+(r + 0.5*(vol_v)^2)*T)/(vol_v *sqrt(T));
d2=d1-vol_v*sqrt(T);
D_0_2= F*exp(-r*T)*normcdf(d2) + V_0 * normcdf(-d1);
%   I keep this formula because i still need d1 and d2

l= (F*exp(-r*T))/V_0;
s_0_1= -(1/T) * log(normcdf(d2)+ (1/l) * normcdf(-d1));
RR = (V_0/F) * exp(r*T)*(normcdf(-d1)/normcdf(-d2));
fprintf("Debt Value at t=0 is  %0f \n",D_0);
fprintf("1 Year Term Spread is  %0f \n",s_0_1);
fprintf("The endogenous Recover is  %0f \n",RR);
fprintf("Volatility of firm value is  %0f \n",vol_v)
%%
%   1.
clc
close
clear
bluecolor=[0, 0, 125/255];
redcolor=[126/255, 0, 0];
greencolor=[0, 126/255,0];

k=0.3;
theta=0.15;
sigma=0.2;
T=5;
N=100*T;
dt=T/N;
i=0:500;
%i=500

%   We are going to use the formula of the Bond applied to our case.

h=sqrt(k^2+2*sigma^2);
alpha=((2*h*exp((k+h)*dt*i/2))./(2*h+(k+h)*(exp(h*dt*i)-1))).^(2*k*theta/sigma^2);
beta=(2*(exp(h*dt*i)-1))./(2*h+(k+h)*(exp(h*dt*i)-1));
S=alpha.*exp(-beta*theta);
%figure;
plot(i/N,S,"Color",greencolor)
title("Survival probability")
ylim([min(S), max(S)]);
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/Survival_probability.png', '-png', '-transparent');
%%
%   2.

LGD=5000000;
r=0.035;
PremLeg=0;
for j=1:T
PremLeg=PremLeg+sum([1*exp(-r*j)*S((j*100)+1)])
end

ts=0:dt:T
ProtLeg=0;

for l=1:N
ProtLeg=ProtLeg+((exp(-r*ts(l))+exp(-r*ts(l+1)))/2)*(S(l+1)-S(l))
end
ProtLeg=-LGD*ProtLeg
R=ProtLeg/PremLeg
fprintf('The value of the Fair Premium is %0f', R);
%%
clc
close
clear
k=0.3;
theta=0.15;
sigma=0.2;

payments_frequency=1;
LGD=5;
r=0.035;

%%
clc
close
clear
N=1000;
bluecolor=[0, 0, 125/255];
redcolor=[126/255, 0, 0];
greencolor=[0, 126/255,0];
%delta_t=[3 6 9 12 15 18 21 22]/12; % i divide the months by the total
delta_t=[0.25 0.5 0.75 1 1.25 1.5 1.75 2];
% amount of the months in a year. I prefer to do this with Matlab, instead
%on writing manually the amount because of 22.
n_d=[2 5 9 12 16 20 25 29];
S=1-n_d/N; %n_d corresponds to the sum of the indicator functions

Gom_lambda=@(t,gom_lambda,gom_gamma)gom_lambda*gom_gamma*exp(gom_gamma*t)

% Lambda with an Exponential

Exponential=@(lambda,delta_t)(exp(-lambda*delta_t));
Lambda_exp=lsqcurvefit(Exponential,0,delta_t,S);

% Piecewise exponential
Piecewise_exp=@(lambda,delta_t)(exp(-lambda*delta_t));
% Lambda and Gamma with Gompertz

Gompertz=@(lambda_gamma,delta_t)(exp(lambda_gamma(1)*(1-exp(lambda_gamma(2)*delta_t))));
lambda_gamma=lsqcurvefit(Gompertz,[0.02 0.3],delta_t,S);
Lambda_gom=lambda_gamma(1);
Gamma_gom=lambda_gamma(2);

%Piecewise constant
piecewise_lambda=zeros(1,8);
piecewise_lambda(1)=-log(S(1))/(0.25)*100;
for i=2:8
    piecewise_lambda(i)=(log(S(i-1))-log(S(i)))/(delta_t(i)-delta_t(i-1))*100;
end
t=linspace(0,2.50,100)
t2=linspace(0,2.50,9)
%   Hazard function
figure;
plot(t,Gom_lambda(t,Lambda_gom,Gamma_gom)*100,"Color",redcolor,"LineStyle","--")
hold on
plot([0,2.50],[Lambda_exp,Lambda_exp]*100,"Color",bluecolor)
hold on
for i=1:8
    plot([delta_t(i)-0.25,delta_t(i)],[piecewise_lambda(i),piecewise_lambda(i)],"Color",greencolor)
    hold on
end
plot([2,2.50],[piecewise_lambda(8),piecewise_lambda(8)],"Color",greencolor)
export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/Figure3_33.png', '-png', '-transparent');
%   Survival function
hold off
%figure;
plot(t,Exponential(Lambda_exp*100,t),"Color",bluecolor)
hold on
plot(t,Gompertz([Lambda_gom*100,Gamma_gom],t),"Color",redcolor,"LineStyle","--")
hold on
piece_t=0;
for i=1:8
    piece_t=linspace(delta_t(i)-0.25,delta_t(i),100)
    plot(piece_t,Piecewise_exp(piecewise_lambda(i),piece_t),"Color",greencolor)
    hold on
end
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/Survival3_33.png', '-png', '-transparent');
hold off

%%
clc
close
clear
bluecolor=[0, 0, 125/255];
redcolor=[126/255, 0, 0];
greencolor=[0, 126/255,0];

CMM= [92.82 6.50 0.56 0.06 0.06 0.00 0.00 0.00;
      0.63 91.87 6.64 0.65 0.06 0.11 0.04 0.00;
      0.08 2.26 91.66 5.11 0.61 0.23 0.01 0.04;
      0.05 0.27 5.84 87.74 4.74 0.98 0.16 0.22;
      0.04 0.11 0.64 7.85 81.14 8.27 0.89 1.06;
      0.00 0.11 0.30 0.42 6.75 83.07 3.86 5.49;
      0.19 0.00 0.38 0.75 2.44 12.03 60.71 23.50;
      0.00 0.00 0.00 0.00 0.00 0.00 0.00 100.00];
CMM=CMM/100;
%%
%CMM2
CMM1=CMM;
for i=1:8
    for j=1:8
        CMM2(i,j)=dot(CMM1(i,:),CMM(:,j));
        
    end
end
CMM2=CMM2*100; 
%%
%CMM5
CMM1=CMM;
for k=2:2

for i=1:8
    for j=1:8
        CMM5(i,j)=dot(CMM1(i,:),CMM(:,j));
        
    end
end
CMM1=CMM5;
end
CMM5=round(CMM5*100,2);
A=array2table(CMM2)
%%
t=150;
CMM1=CMM;
hazard=zeros(7,t-1)

for k=2:t
for i=1:8
    for j=1:8
        CMM2(i,j)=dot(CMM1(i,:),CMM(:,j));
        
    end
end
hazard(1:7,k-1)=log((1-CMM1(1:7,8))./(1-CMM2(1:7,8)))
CMM1=CMM2;
end

%figure;
tiledlayout(2,2);

nexttile

plot(hazard(1,:)*10000,"Color",bluecolor)
hold on
plot(hazard(2,:)*10000,"Color",redcolor,"LineStyle","--")
legend("AAA","AA","Location","best")

nexttile
plot(hazard(3,:)*10000,"Color",bluecolor)
hold on
plot(hazard(4,:)*10000,"Color",redcolor,"LineStyle","--")
legend("A","BBB","Location","best")

nexttile
plot(hazard(5,:)*10000,"Color",bluecolor)
hold on
plot(hazard(6,:)*10000,"Color",redcolor,"LineStyle","--")
legend("BBB","B","Location","best")

nexttile
plot(hazard(7,:)*10000,"Color",bluecolor)
legend("CCC","Location","best")
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/Figure3_35.png', '-png', '-transparent');
%%
clc
clear
close
CMM= [92.82 6.50 0.56 0.06 0.06 0.00 0.00 0.00;
      0.63 91.87 6.64 0.65 0.06 0.11 0.04 0.00;
      0.08 2.26 91.66 5.11 0.61 0.23 0.01 0.04;
      0.05 0.27 5.84 87.74 4.74 0.98 0.16 0.22;
      0.04 0.11 0.64 7.85 81.14 8.27 0.89 1.06;
      0.00 0.11 0.30 0.42 6.75 83.07 3.86 5.49;
      0.19 0.00 0.38 0.75 2.44 12.03 60.71 23.50;
      0.00 0.00 0.00 0.00 0.00 0.00 0.00 100.00];
CMM=CMM/100;

%Table 3.37
MG_37=round(logm(CMM)*10000,2);

%Table 3.38
I=eye(8);
MG_38=zeros(8);
for i=1:3
   MG_38=MG_38+ ((-1)^(i+1))*((CMM-I)^i)/i;
end
MG_38=round(MG_38*10000,2);


%Table 3.39
off_I=1-I
Off_Diag=MG_37.*off_I;
Diag=((repmat(sum((Off_Diag<0).*Off_Diag,2),1,8))+MG_37).*I
MG_39=max(Off_Diag,0)+Diag;

%Table 3.40

G=abs(sum(MG_37.*I,2))+sum(max(Off_Diag,0),2);
B=sum(max(-Off_Diag,0),2);

B=repmat(B,1,8);

Zero_cond=(MG_37.*off_I>=0);
MG_40=ones(8)
for i=1:8
    if(G(i)==0)
        MG_40(i,:)=MG_37(i,:)
    else
        MG_40(i,:)=round(Zero_cond(i,:).*(MG_37(i,:)-(B(i,:).*abs(MG_37(i,:)./G(i,:)))),2)
    end
end
%%
A=array2table(MG_40)
%%

bluecolor=[0, 0, 125/255];
redcolor=[126/255, 0, 0];
greencolor=[0, 126/255,0];

t=1:300;
AAA=MG_39(1,:);
AA=MG_39(1,:);
f_AAA_1=zeros(1,300);
f_AA_1=zeros(1,300);

f_AAA_2=zeros(1,300);
f_AA_2=zeros(1,300);
for i=1:300
MG1_i=(MG_39/10000)*expm(i*(MG_39/10000));
f_AAA_1(i)=MG1_i(1,8);
f_AA_1(i)=MG1_i(2,8);

MG2_i=(MG_40/10000)*expm(i*(MG_40/10000));
f_AAA_2(i)=MG2_i(1,8);
f_AA_2(i)=MG2_i(2,8);
end

%figure;
plot(t,f_AAA_2,"Color",bluecolor)
hold on
plot(t,f_AAA_1,"Color",redcolor)
legend("AAA with second approach","AAA with first approach")

%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/AAAsecondandfirst_1.png', '-png', '-transparent');

%%
%figure;
plot(t,f_AAA_2,"Color",bluecolor)
hold on
plot(t,f_AA_2,"Color",redcolor)
legend("AAA with second approach","AA with second approach")
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/AAA_AA_second.png', '-png', '-transparent');

%%





%%
clc
close
clear

n=100000;
T=5;
EAD=1000;
LGD=[0 0.10 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.90 1];
p=[0.01 0.02 0.10 0.25 0.10 0.02 0 0.02 0.10 0.25 0.10 0.02 0.01]; %They sum up to 1
lambda=[10 10 25 25 50 100 250 500 500 1000]/10000;
final_LGD=repelem(LGD,p*n*10)
final_LGD=reshape(final_LGD(randperm(numel(final_LGD))),10,n)
lambda=repmat(lambda',[1,n])

X=repmat(normrnd(0,1,[1,n]),[10,1])
epsilon=normrnd(0,1,[10,n]);
%%
rho=0;
u=normcdf(sqrt(rho).*X +sqrt(1-rho).*epsilon);

tau=[-log(u)./lambda]
indicator=(tau<=T)

L=EAD.*final_LGD.*indicator
L_tot=sum(L,1)
%figure;
histogram(L_tot)
title("\rho =0")
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/Hist_rho0.png', '-png', '-transparent');
%%
Var_99_0=prctile(L_tot,99)
Var_995_0=prctile(L_tot,99.5)
Var_999_0=prctile(L_tot,99.9)
fprintf("VaR 99 is %0f \n",Var_99_0)
fprintf("VaR 99.5 is %0f \n",Var_995_0)
fprintf("VaR 99.9 is %0f \n",Var_999_0)
alpha99_0=linspace(99,100,1000)
ES99_0=mean(prctile(L_tot,alpha99_0))
alpha995_0=linspace(99.5,100,1000)
ES995_0=mean(prctile(L_tot,alpha995_0))
alpha999_0=linspace(99.9,100,1000)
ES999_0=mean(prctile(L_tot,alpha999_0))
fprintf("ES 99 is %0f \n",ES99_0)
fprintf("ES 99.5 is %0f \n",ES995_0)
fprintf("ES 99.9 is %0f \n",ES999_0)
%%
alpha=linspace(99,100,1000)
ES1=mean(prctile(L_tot,alpha))

%%
rho=0.2;
u=normcdf(sqrt(rho).*X +sqrt(1-rho).*epsilon);

tau=[-log(u)./lambda]
indicator=(tau<=T)

L=EAD.*final_LGD.*indicator
L_tot2=sum(L,1)
figure;
histogram(L_tot2)
title("\rho =0.2")
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/Hist_rho2.png', '-png', '-transparent');
%%
Var_99_02=prctile(L_tot2,99)
Var_995_02=prctile(L_tot2,99.5)
Var_999_02=prctile(L_tot2,99.9)
fprintf("VaR 99 is %0f \n",Var_99_02)
fprintf("VaR 99.5 is %0f \n",Var_995_02)
fprintf("VaR 99.9 is %0f \n",Var_999_02)
alpha99_02=linspace(99,100,1000)
ES99_02=mean(prctile(L_tot2,alpha99_02))
alpha995_02=linspace(99.5,100,1000)
ES995_02=mean(prctile(L_tot2,alpha995_02))
alpha999_02=linspace(99.9,100,1000)
ES999_02=mean(prctile(L_tot2,alpha999_02))
fprintf("ES 99 is %0f \n",ES99_02)
fprintf("ES 99.5 is %0f \n",ES995_02)
fprintf("ES 99.9 is %0f \n",ES999_02)
%%
rho=0.5;
u=normcdf(sqrt(rho).*X +sqrt(1-rho).*epsilon);

tau=[-log(u)./lambda]
indicator=(tau<=T)

L=EAD.*final_LGD.*indicator
L_tot5=sum(L,1)
%figure;
histogram(L_tot5)
title("\rho =0.5")
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/Hist_rho5.png', '-png', '-transparent');
%%
Var_99_05=prctile(L_tot5,99)
Var_995_05=prctile(L_tot5,99.5)
Var_999_05=prctile(L_tot5,99.9)
fprintf("VaR 99 is %0f \n",Var_99_05)
fprintf("VaR 99.5 is %0f \n",Var_995_05)
fprintf("VaR 99.9 is %0f \n",Var_999_05)
%%
alpha99_5=linspace(99,100,1000)
ES99_5=mean(prctile(L_tot5,alpha99_5))
alpha995_5=linspace(99.5,100,1000)
ES995_5=mean(prctile(L_tot5,alpha995_5))
alpha999_5=linspace(99.9,100,1000)
ES999_5=mean(prctile(L_tot5,alpha999_5))
fprintf("ES 99 is %0f \n",ES99_5)
fprintf("ES 99.5 is %0f \n",ES995_5)
fprintf("ES 99.9 is %0f \n",ES999_5)
%%
clc
close
clear

Q=100;
S_0=100;
K=100;
T=1;
r=0.05;
sigma=0.2;

t_0=0.5;
S_t0=114.77;
N=10000;


%   Now, we exploit the fact that the asset prices evolve as a GBM

n=100;
t=T/2;
dt=t/n;
S_05=zeros(1,n);

drift=repmat(dt,[1,n]);
increment_drift=cumsum(drift)
while(round(S_05(100),2)~=S_t0)
diffusion=normrnd(0,sqrt(dt),[1,n]);
increment_diff=cumsum(diffusion)
increment=exp((r-(sigma^2)/2)*increment_drift+sigma*increment_diff)
S_05=S_0*increment;
end

N=10000;

diffusion_simul_incr=cumsum(normrnd(0,sqrt(dt),[N,n]),2);

drift_simul_incr=repmat(t_0+increment_drift,N,1)

increment_simul=exp(sigma*diffusion_simul_incr+(r-(sigma^2)/2)*drift_simul_incr)
S_simul=S_t0*increment_simul;
figure;
plot(linspace(0.5,1,n),S_simul);
hold on
plot(linspace(0,0.5,n),S_05);
export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/GeometricBrownianMotion.png', '-png', '-transparent');
%%
%   apply Black and Scholes to obtain C_0
d1=(log(S_0 / K)+(r + 0.5*(sigma)^2)*T)/(sigma *sqrt(T));
d2=d1-sigma*sqrt(T);

C_0= S_0 * normcdf(d1) - K*exp(-r*T)*normcdf(d2);
S_1=S_simul(:,100);
C_1=max(S_1-S_0,0);

MtM_1=Q*(C_1-C_0);
e_1=max(MtM_1,0);
%%
%figure;
tiledlayout(1,2);
nexttile
[f, xi] = ksdensity(MtM_1);
plot(xi, f, "LineStyle","--","Color","blue");
xlabel("MtM(0,1)")
title("Density")
nexttile
[f2, xi2] = ksdensity(e_1);
plot(xi2, f2, "LineStyle","--","Color","red");
xlabel("e(1)")
title("Density")
%export_fig('C:\Users\AlexD\OneDrive\Desktop\QRM\Credit Risk\QRM\Graphs/GBM.png', '-png', '-transparent');

%%
S_t0=114.77
t_0=0.5

d1=(log(S_t0 / K)+(r + 0.5*(sigma)^2)*t_0)/(sigma *sqrt(t_0));
d2=d1-sigma*sqrt(t_0);

C_t0= S_t0 * normcdf(d1) - K*exp(-r*t_0)*normcdf(d2);


MtM_t1=Q*(C_1-C_t0);
e_t1=max(MtM_t1,0);

EE=mean(e_t1)
PFE_95=prctile(e_t1,95)
PFE_99=prctile(e_t1,99)
fprintf("Expected Exposure is %0f \n",EE)
fprintf("Potential Future Exposure at 95 is %0f \n",PFE_95)
fprintf("Potential Future Exposure at 99 is %0f \n",PFE_99)
%%
E_LGD=0.5;
PD=0.02;
CVA=C_0*(1-E_LGD*PD)
fprintf("CVA at time 0 is %0f \n",CVA)